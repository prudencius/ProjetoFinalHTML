<html>
    <body style="background-color:firebrick">
        
    </body>
</html>

<?php

include_once "../servico/BdPosts.php";

$id=$_GET["id"];

$sql= "DELETE FROM Blog WHERE id=$id";
$bd= new BdPosts();
$contador = $bd->exec($sql);

echo "<h1 style='color:white'>Foi excluído $contador post</h1>";

?>

<a href="ConsultaPosts.php" style="color:white"> < Voltar </a>