<html>
    <body style="background-color:firebrick">
        
    </body>
</html>

<?php

include_once "../servico/BdPosts.php";

$titulo=$_GET["titulo"];
$corpo=$_GET["corpo"];

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $sql= "UPDATE `Blog` set titulo='$titulo', corpo='$corpo' where id='$id' ";
}else{
$sql= "INSERT INTO `Blog` (`id`, `titulo`, `corpo`) VALUES (NULL, '$titulo', '$corpo')";
}

$bd = new BdPosts();
$bd->exec($sql);

echo "<h1 style='color:white'>Post salvo com sucesso!</h1>";

?>

<a href="../homepage.php" style="color:white"> < Voltar para a HOMEPAGE </a>