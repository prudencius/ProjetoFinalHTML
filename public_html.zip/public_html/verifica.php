<?php
session_start();

$login=$_POST["login"];
$senha=$_POST["senha"];

include_once "servico/Bd.php";
    
    $bd = new Bd();
    $sql = "select * from usuario where login='$login' and senha='$senha'";
    
foreach ($bd->query($sql) as $row) {
    $_SESSION["autenticado"]=true;
    
    $html ="
    <html>
        <head><title>Tela de verificação </title></head>
        <body>
         <script>
         window.location.replace('https://vitorvprudencio.000webhostapp.com//menu.php');
         </script>
        </boyd>
    </html>

";    

    echo $html;
    return;
}

    session_destroy ( ) ;
    $html ="
<html>
    <head><title>Tela de verificação </title></head>
    <body style='background-color:firebrick'>
        <h1 style='color:white'>O login é $login e sua senha é $senha e são inválidos</h1>
        <a href='../homepage.php' style='color:white'> < Voltar para a HOMEPAGE </a>
    </boyd>
</html>

";
    




echo $html;
?>