<html>
    <body style="background-color:firebrick">
        
    </body>
</html>

<?php

include_once "../servico/Bd.php";

$id=$_GET["id"];

$sql= "DELETE FROM usuario WHERE id=$id";
$bd= new Bd();
$contador = $bd->exec($sql);

echo "<h1 style='color:white'>Foi excluído $contador registro</h1>";

?>

<a href="ConsultaUsuario.php" style="color:white"> < Voltar </a>