<html>
    <body style="background-color:firebrick">
        
    </body>
</html>

<?php

include_once "../servico/Bd.php";

$login=$_GET["login"];
$senha=$_GET["senha"];

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $sql= "UPDATE `usuario` set login='$login', senha='$senha' where id='$id' ";
}else{
    $sql= "INSERT INTO `usuario` (`id`, `login`, `senha`) VALUES (NULL, '$login', '$senha')";
}


$bd= new Bd();
$contador = $bd->exec($sql);

echo "<h1 style='color:white'>Usuário criado/alterado com sucesso!!</h1>";

?>

<a href="ConsultaUsuario.php" style="color:white"> < Voltar </a>